<?php

$firstname = "Iam";
$lastname = "Batman :)";

echo $firstname . " " . $lastname;
?>